import pandas
import numpy
import pathlib
import scipy.integrate
import scipy.signal
from functools import partial


def rmsa(signals):
    """
    Compute the Root Mean Square of signal Amplitude from Phyomark et al. 2012
    :param signals: an array of equally long signals
    :return signal's rmsA:
    """
    # return numpy.mean(signals, axis=-1)
    return numpy.sqrt(numpy.mean((signals ** 2), axis=-1))


def mdf(freqs, psds):
    """
        Compute the MeDian Frequency of the PSD.
        Input parameters can be computed with the function PSD_Freq_Welch(signal,SamplingRate):
        :param freqs: frequencies (Hz) at which the power was computed
        :param psds: power spectrum associated to Freqs:
        :return the median of the signal's power spectrum:
    """

    try:
        med_freqs = freqs[
            range(freqs.shape[0]),
            numpy.apply_along_axis(numpy.argmax, 1, psds.cumsum(axis=1) > psds.sum(axis=1)[:, numpy.newaxis] * 0.5,),
        ]
    except numpy.AxisError:
        med_freqs = freqs[numpy.argmax(psds.cumsum() > psds.sum() * 0.5)]
    return numpy.round(med_freqs, decimals=2)


def psd_freq(signals, fs=2048):

    return numpy.apply_along_axis(
        scipy.signal.welch, -1, signals, fs=fs, nperseg=signals.shape[-1], window="hanning", detrend="constant",
    )


def apply_freq_func(func, signals, fs=2048):
    frequencies, psds = numpy.split(psd_freq(signals, fs), 2, axis=-2)
    return func(frequencies.squeeze(), psds.squeeze())


def fhn(t, x, alpha, beta, gamma, delta, epsilon):
    [v, w] = x
    dv = (alpha - v) * (v - 1) * v - w
    dw = epsilon * (beta * v - gamma * w - delta)
    return dv, dw


def run_fhn(param):
    if not isinstance(param, dict):
        param = {k[0]: v for k, v in param.to_dict().items()}
        # print(param)
    res = scipy.integrate.solve_ivp(
        partial(fhn, **param), [0, 1000], [0, 0], method="RK45", t_eval=numpy.arange(0, 1000, 0.5)
    )
    v, w = res["y"]
    features = dict()
    features["v_rms"] = rmsa(v)
    features["w_rms"] = rmsa(w)
    features["v_mdf"] = apply_freq_func(mdf, v)
    features["w_mdf"] = apply_freq_func(mdf, w)

    return pandas.Series(features)


def run_fhn_base(param):
    if not isinstance(param, dict):
        param = {k[0]: v for k, v in param.to_dict().items()}
        # print(param)
    res = scipy.integrate.solve_ivp(
        partial(fhn, **param), [0, 1000], [0, 0], method="RK45", t_eval=numpy.arange(0, 1000, 0.5)
    )

    return res


def main(subdir=".", pattern="Population*.csv"):
    directory = pathlib.Path(subdir)
    doe_files = directory.glob(pattern)
    for file in doe_files:
        df_doe = pandas.read_csv(file, index_col=0, header=[0, 1])
        df_results = df_doe.apply(run_fhn, axis=1)
        df_results.name = "FHN"
        df_results.to_csv(directory / (file.stem.replace("Population", "Outputs") + ".csv"))

        print(file, "\n", df_results.head())
